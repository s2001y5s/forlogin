var part = require('./mpart.js')
part.f();
